# Welcome to the Simon effect - Feedback!

In this experiment we are again increasing complexity but this time in an incremental fashoin - we'll be adding to the Simon Effect from the last experiment. If you run the experiment from scratch you should see that it doesn't work properly - you'll need to fix it as you make changes below. The idea is that after each trial you should be told whether or not you responded correctly. In this experiment we are starting to introduce some very basic code - if you're not familiar with code **don't panic**. We'll introduce some simple snipptes of code and you won't need to be an expert to make your own experiment do what you want. 

As we said the experiment is again looking at the Simon effect - there are 4 trials 2 congruent and 2 incongruent. But if you run the experiment you don't get the appropriate feedback! Let's make some changes so that it works and then experiment a bit further: 

1. Try to get the feedback working!

2. Change the colour and text of the feedback to anything you want. 

3. Modify the experiment so that you have a timelimit to respond in - can you then modify the feedback so it says 'Too slow!' if no response was given? (this can be tricky).


If you need help - speak to instructors in class, check the online guide or contact a member of staff via email.







