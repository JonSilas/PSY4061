# Welcome to the Branching program

You've been introduced to a small amount of coding and hopefully you can see how powerful it is - based on responses and their relation to the components and properties of the experiment you can modify what happens. Another useful aspect of this is 'branching' based on a response from the participant you may want to re-run a practice set of trials or exit an experiment early if the participant doesn't consent (for example).

Although this experiment is simpler than the previous one - more is missing and there's more for you to do to make it function as it is supposed to - you may have to type some code! Remember **don't panic** we'll help you through it. At the moment you see some instructions, and then irrespective of what key you press you then see a picture of a cat and then a dog. The idea is that you should be able to choose what you see next.  

You'll need to get the experiment working appropriately, check the online guide for support and if you get stuck ask an instructor in class or send them an email.

See what you can change: 

1. Make the appropriate changes to the code and the routines so that when you press C you will see an image of a cat, when you press D you see a picture of a dog and when you press R the instructions repeat. 

2. Change the images, draw from a list in an excel document and do so randomly. 

3. Add responses to the images can you add new routines to jump to? Maybe add a goodbye message before the experiment ends?

4. Can you set up something useful - could you modify the experiment to have a 'press y to consent and continue' or 'press n to refuse consent and exit?
