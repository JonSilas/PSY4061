## Welcome to the Blocking experiment

Up till now we have had a strong focus on 'trials' - that is, one instance of one condition that a participant typically generates one response for (complicated experiments may vary slightly). A 'block' of trials is usually the repetition of multiple trials. Within a block each trial may vary based on its condition and the only reason you would 'block' trials would be to give participants a break. Sometimes, when, cognition might be affected by adjacent trials, it might be better to separate conditions across blocks - this is typically referred to as a 'blocked' condition or paradigm. 

In this experiment we will have a simple trial with two conditions - we will then try set up the experiment so that we vary those conditions randomly within a block and take breaks. Then we will try to set up the experiment so that there is one condition in each block. 

This task is a perceptual discrimination task - whilst fixating your gaze on the fixation cross participants are asked to judge if lines on either side of the cross are the same length or different. Currently the experiment runs through instructions, two trials (one in the 'same' condition, the other in the 'different' condition) a break screen and then ends. 

You need to modify the experiment: 

1. Add another block, so that you are presented with one trial from each condition then a break before another block of the same. 

2. Modify your experiment so that you present two trials from the 'same' condition in one block, and two trials from the 'different' condition in another. 

3. For either block, format present a different message in the break for each block, for example 'that was the first block, you have one more to go' for the end of the first block but something different for the last block. 

