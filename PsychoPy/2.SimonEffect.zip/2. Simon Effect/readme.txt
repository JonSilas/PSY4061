# Welcome to the Simon effect experiment!

We are already starting to get a little more complicated with our PsychoPy experiments. Run the experiment before you start editing it by pressing the play button, entering any participant number, and pressing 'ok'. In this experiment you are first given some instructions and then asked to respond to 'green' and 'red' circle stimuli. The Simon effect is an effect of reaction times - people are faster at responding with their left hand, on the left, when a stimulus is on the left - same for the right side too. This is compared to when you must make a response using your hand on the opposite side of a stimulus. This little experiment will actually generate some data!  

As it stands, the experiment will first, give you some instructions then run you through two 'congruent' trials - were the side of the stimuli and the side of the response match. After that it will end. 

Let's see if you can make a few changes and perhaps even get some simple data to look at. 

1. Can you add two more trials in the 'incongruent' condition - so that a red circle appears on the right in one trial and a green circle on the left in another trial?

2. Once you've added more conditions, make sure they appear in a random order and add more repetitions of trials; so that the number of trials per condition repeat - set it for 5 repetitions per condition. 

3. At the moment the stimuli stays on the screen until a response. To increase errors and speed up responses can you have set a time limit so that the participant only has 2 seconds to respond? 

4. Can you manipulate the `key-resp` component in the `trial` routine so that it stores the correct answer?


If you need help - speak to instructors in class, check the online guide or contact a member of staff via email.






