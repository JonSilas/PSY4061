# Welcome to Hello World!

This is a very simple 'experiment'. Run the experiment before you start editing it by pressing the play button, entering any participant number and pressing 'ok'. You should see a screen that displays the numbers 3, 2 then 1 - each number is on the screen for one second. Finally, a screen saying 'Hello World (press space to end)' will be shown - press space to finish. Now you know what the experimental file does, it's time to start playing around with it. Feel free to try whatever you want, but here are some things to guide your exploration: 

1. Change the order of the numbers so they appear in random. 
2. Make the numbers appear on the screen for only 0.5 seconds. 
3. Add more numbers - count down from 10. 
4. Make the numbers stay on the screen until a response from the participant is given.
5. Change the numbers so that they display traffic light images - red, amber and green. 

If you need help - speak to instructors in class, check the online guide or contact a member of staff via email. 
